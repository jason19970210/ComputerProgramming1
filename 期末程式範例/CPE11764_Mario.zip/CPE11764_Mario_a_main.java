import java.util.Scanner;  //�u��main�����઩ 

class CPE11764_Mario_a_main {

	public static void main(String args[]) {
		Scanner inp = new Scanner(System.in);
		System.out.print("? ");
		int N = inp.nextInt();
		int jUp = 0, jDown = 0;
		int now = inp.nextInt(), next = 0;
		for (int i = 1 + 1; i <= N; i++) {
			next = inp.nextInt();
			if (now < next)
				jUp++;
			else if (now > next)
				jDown++;
			now = next;
		}
		System.out.println(jUp + " " + jDown);
	} // ========//
} /**** end_of_class ****/
//3
//8 1 4 2 2 3 5 3 4
//5 1 2 3 4 5
//1 9
