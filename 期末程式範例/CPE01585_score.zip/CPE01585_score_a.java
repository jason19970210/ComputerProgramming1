class CPE01585_score_a {
	static java.util.Scanner inp = new java.util.Scanner(System.in);

	public static void main(String args[]) {
		System.out.print("? ");
		String s = inp.next(); // �浧�� Scanner.next() �ĪG���� Scanner.nextLine()
		int ans = DoIt(s);
		System.out.println(ans);
	} // ========//

	private static int DoIt(String s) {
		int ans = 0, OO = 0;
		for (int i = 0; i < s.length(); i++)
			if (s.charAt(i) == 'O')
				ans += (++OO);
			else
				OO = 0;
		return ans;
	} // ========//
} /**** end_of_class ****/
//3
//OOXXOXXOOO
//OXOX
//X
//-1
