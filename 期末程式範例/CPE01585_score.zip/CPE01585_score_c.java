class CPE01585_score_c {
	static java.util.Scanner inp = new java.util.Scanner(System.in);

	public static void main(String args[]) {
		System.out.print("? ");
		while (true) {
			String s = inp.next();
			if (s.equals("-1")) // ���U���n�� if (s == "-1") !!!
				break;
			int ans = DoIt(s);
			System.out.println(ans);
		}
	} // ========//

	private static int DoIt(String s) {
		int ans = 0, OO = 0;
		for (int i = 0; i < s.length(); i++)
			if (s.charAt(i) == 'O')
				ans += (++OO);
			else
				OO = 0;
		return ans;
	} // ========//
} /**** end_of_class ****/
//3
//OOXXOXXOOO
//OXOX
//X
//-1
