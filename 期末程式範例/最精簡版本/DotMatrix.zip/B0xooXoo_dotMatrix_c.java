public class B0xooXoo_dotMatrix_c {
	static java.util.Scanner inp = new java.util.Scanner(System.in);
	static final int SIZE = 5, MAX = SIZE - 1;
	static char D0 = '%', D1 = '.';

	public static void main(String[] args) {
		System.out.print("? ");
		while (true) {
			String dat = GetInput();
			if (dat.equals("-1"))
				break;
			String ans = DoIt(dat);
			System.out.println(ans);
		}
	} // ========//

	private static String DoIt(String dat) {
		String border = new String(new char[SIZE]).replaceAll("\0", "" + D0);
		String ans = border + D0 + "\n", pre = "";
		for (int i = 0; i < dat.length(); i++) {
			String[] line = DrawLetter(dat.charAt(i));
			for (int r = 0; r < line.length; r++)
				ans += (pre += D0) + line[r] + D0 + "\n";
			ans += (pre += D0) + border + D0 + "\n";
		}
		return ans;
	} // ========//

	private static String GetInput() {
		return inp.nextLine().toUpperCase();
	} // ========//

	public static String[] DrawLetter(char ch) {
		switch (ch) {
		case 'X':
			return DrawX();
		case 'Y':
			return DrawY();
		case 'Z':
			return DrawZ();
		case 'H':
			return DrawH();
		case 'N':
			return DrawN();
		case 'T':
			return DrawT();
		default:
			return null;
		}
	} // ========//

	public static String[] DrawH() {
		int[][] a = new int[SIZE][SIZE];
		for (int r = 0; r <= MAX; r++)
			a[r][0] = a[r][MAX] = 1;
		for (int c = 0; c <= MAX; c++)
			a[MAX / 2][c] = 1;
		return AryToLine(a);
	} // ========//

	public static String[] DrawN() {
		String s = "";
		for (int r = 0; r <= MAX; r++) {
			for (int c = 0; c <= MAX; c++)
				if (r == c)
					s += D1;
				else if (c == 0)
					s += D1;
				else if (c == MAX)
					s += D1;
				else
					s += D0;
			s += "\n";
		}
		return StrToLine(s);
	} // ========//

	public static String[] DrawT() {
		String[] ln = new String[SIZE];
		for (int r = 0; r <= MAX; r++) {
			ln[r] = "";
			for (int c = 0; c <= MAX; c++)
				if (r == 0)
					ln[r] += D1;
				else if (c == MAX / 2)
					ln[r] += D1;
				else
					ln[r] += D0;
		}
		return ln;
	} // ========//

	public static String[] DrawX() {
		String s = "";
		for (int r = 0; r <= MAX; r++) {
			for (int c = 0; c <= MAX; c++)
				if (r == c)
					s += D1;
				else if (r == MAX - c)
					s += D1;
				else
					s += D0;
			s += "\n";
		}
		return StrToLine(s);
	} // ========//

	public static String[] DrawY() {
		int[][] a = new int[SIZE][SIZE];
		for (int r = 0; r <= MAX / 2; r++)
			a[r][r] = 1;
		for (int r = 0; r <= MAX / 2; r++)
			a[r][MAX - r] = 1;
		for (int r = MAX / 2; r <= MAX; r++)
			a[r][MAX / 2] = 1;
		return AryToLine(a);
	} // ========//

	public static String[] DrawZ() {
		String[] ln = new String[SIZE];
		for (int r = 0; r <= MAX; r++) {
			ln[r] = "";
			for (int c = 0; c <= MAX; c++)
				if (r == MAX - c)
					ln[r] += D1;
				else if (r == 0)
					ln[r] += D1;
				else if (r == MAX)
					ln[r] += D1;
				else
					ln[r] += D0;
		}
		return ln;
	} // ========//

	public static String AryToStr(int[][] a) {
		String s = "";
		for (int r = 0; r <= MAX; r++) {
			for (int c = 0; c <= MAX; c++)
				s += (a[r][c] == 0) ? D0 : D1;
			s += "\n";
		}
		return s;
	} // ========//

	public static int[][] LineToAry(String[] ln) {
		int[][] a = new int[SIZE][SIZE];
		for (int r = 0; r <= MAX; r++)
			for (int c = 0; c <= MAX; c++)
				a[r][c] = (ln[r].charAt(c) == D0) ? 0 : 1;
		return a;
	} // ========//

	public static String[] StrToLine(String s) {
		return s.split("\n");
	} // ========//

	public static String LineToStr(String[] ln) {
		return String.join("\n", ln) + "\n";
	} // ========//

	public static int[][] StrToAry(String s) {
		return LineToAry(StrToLine(s));
	} // ========//

	public static String[] AryToLine(int[][] a) {
		return (StrToLine(AryToStr(a)));
	} // ========//

} /**** end_of_class ****/
//3
//xYz
//hNnt
//xHyNzT
//-1

//%%%%%%
//%.%%%.%
//%%%.%.%%
//%%%%%.%%%
//%%%%%.%.%%
//%%%%%.%%%.%
//%%%%%%%%%%%%
//%%%%%%%.%%%.%
//%%%%%%%%%.%.%%
//%%%%%%%%%%%.%%%
//%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%.%%
//%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%.%%%%
//%%%%%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%%%%%%%%
//
//%%%%%%
//%.%%%.%
//%%.%%%.%
//%%%.....%
//%%%%.%%%.%
//%%%%%.%%%.%
//%%%%%%%%%%%%
//%%%%%%%.%%%.%
//%%%%%%%%..%%.%
//%%%%%%%%%.%.%.%
//%%%%%%%%%%.%%..%
//%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%..%%.%
//%%%%%%%%%%%%%%%.%.%.%
//%%%%%%%%%%%%%%%%.%%..%
//%%%%%%%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//
//%%%%%%
//%.%%%.%
//%%%.%.%%
//%%%%%.%%%
//%%%%%.%.%%
//%%%%%.%%%.%
//%%%%%%%%%%%%
//%%%%%%%.%%%.%
//%%%%%%%%.%%%.%
//%%%%%%%%%.....%
//%%%%%%%%%%.%%%.%
//%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%.%.%%
//%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%%%%%%..%%.%
//%%%%%%%%%%%%%%%%%%%%%.%.%.%
//%%%%%%%%%%%%%%%%%%%%%%.%%..%
//%%%%%%%%%%%%%%%%%%%%%%%.%%%.%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.....%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%.%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%