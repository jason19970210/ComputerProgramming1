class CPE11764_Mario_c {
	static java.util.Scanner inp = new java.util.Scanner(System.in);

	public static void main(String args[]) {
		System.out.print("? ");
		while (true) {
			int[] dat = GetInput();
			if (dat == null)
				break;
			String ans = DoIt(dat);
			System.out.println(ans);
		}
	} // ========//

	private static int[] GetInput() {
		int N = inp.nextInt();
		if (N < 0)
			return null;
		int[] dat = new int[N];
		for (int i = 0; i < N; i++)
			dat[i] = inp.nextInt();
		return dat;
	} // ========//

	private static String DoIt(int[] dat) {
		int jUp = 0, jDown = 0;
		for (int i = 1; i < dat.length; i++)
			if (dat[i - 1] < dat[i])
				jUp++;
			else if (dat[i - 1] > dat[i])
				jDown++;
		return jUp + " " + jDown;
	} // ========//
} /**** end_of_class ****/
//3
//8 1 4 2 2 3 5 3 4
//5 1 2 3 4 5
//1 9
//-1
