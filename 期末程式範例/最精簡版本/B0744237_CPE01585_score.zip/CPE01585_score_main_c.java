class CPE01585_score_main_c {

	public static void main(String args[]) {
		java.util.Scanner inp = new java.util.Scanner(System.in);
		System.out.print("? ");
		while (true) {
			String s = inp.next(), t[] = s.split("X");
			if (s.equals("-1"))
				break;
			int sum = 0;
			for (int i = 0; i < t.length; i++)
				sum += (1 + t[i].length()) * t[i].length() / 2;
			System.out.println(sum);
		}
	} // ========//
} /**** end_of_class ****/
//3
//OOXXOXXOOO
//OXOX
//X
//-1
