public class B0xooXoo_triangle_c {
	public static void main(String[] args) {
		java.util.Scanner inp = new java.util.Scanner(System.in);
		System.out.print("? ");
		while (true) {
			int a = inp.nextInt();
			if (a < 0)
				break;
			int b = inp.nextInt(), c = inp.nextInt();
			if (a > b) {
				int tmp = a;
				a = b;
				b = tmp;
			}
			if (b > c) {
				int tmp = b;
				b = c;
				c = tmp;
			}
			String ans = "";
			if (a + b <= c)
				ans = "bad";
			else if (a * a + b * b == c * c)
				ans = "right";
			else if (a * a + b * b > c * c)
				ans = "acute";
			else if (a * a + b * b < c * c)
				ans = "obtuse";
			System.out.println(ans);
		}
	} // ========//
} /**** end_of_class ****/
//4
//4 4 3
//5 4 3
//6 4 3
//7 4 3
//-1

//acute
//right
//obtuse
//bad
