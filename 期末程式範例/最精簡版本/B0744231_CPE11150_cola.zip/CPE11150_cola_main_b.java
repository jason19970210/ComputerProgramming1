class CPE11150_cola_main_b {

	public static void main(String args[]) {
		java.util.Scanner inp = new java.util.Scanner(System.in);
		System.out.print("? ");
		int total = inp.nextInt();
		for (int rec = 0; rec < total; rec++) {
			int N = inp.nextInt();
			System.out.println(N / 2 + N);
		}
	} // ========//
} /**** end_of_class ****/
//3
//8
//9
//1
//-1

//12
//13
//1