import Foundation

struct Question {
    let title: (Int, Int)
    let choices: [Int]
}
